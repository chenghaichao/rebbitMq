package com.example.testrabbitmqconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestRabbitmqConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
